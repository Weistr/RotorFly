/**
  ******************************************************************************
  * @file    usart.c
  * @brief   This file provides code for the configuration
  *          of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */
#include "stdbool.h"
#include "pid.h"
#include "control.h"
#include "STMflash.h"
bool att_offset_flag = 0;
uint8_t uart_rx_buf[64];
uint8_t uart_tx_buf[64];
uint8_t test_flag1 = 0;
uint8_t uart_TXpack_length;
uint8_t uart_RXpack_length;
extern float battery_vot;
#define first_byte 0x5A
#define last_byte 0xA5

//ң�������͵�����
extern RC_TYPE RC_Control;
//������̬У׼


bool offset_save_flag = 0;

/* USER CODE END 0 */

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart1_rx;
DMA_HandleTypeDef hdma_usart1_tx;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;

/* USART1 init function */

void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}
/* USART2 init function */

void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspInit 0 */

  /* USER CODE END USART1_MspInit 0 */
    /* USART1 clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART1 DMA Init */
    /* USART1_RX Init */
    hdma_usart1_rx.Instance = DMA1_Channel5;
    hdma_usart1_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_usart1_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart1_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart1_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart1_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart1_rx.Init.Mode = DMA_NORMAL;
    hdma_usart1_rx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart1_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmarx,hdma_usart1_rx);

    /* USART1_TX Init */
    hdma_usart1_tx.Instance = DMA1_Channel4;
    hdma_usart1_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_usart1_tx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart1_tx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart1_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart1_tx.Init.Mode = DMA_NORMAL;
    hdma_usart1_tx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmatx,hdma_usart1_tx);

  /* USER CODE BEGIN USART1_MspInit 1 */

  /* USER CODE END USART1_MspInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */
    /* USART2 clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART2 GPIO Configuration
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART2 DMA Init */
    /* USART2_RX Init */
    hdma_usart2_rx.Instance = DMA1_Channel6;
    hdma_usart2_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_usart2_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart2_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart2_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart2_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart2_rx.Init.Mode = DMA_NORMAL;
    hdma_usart2_rx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart2_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmarx,hdma_usart2_rx);

    /* USART2_TX Init */
    hdma_usart2_tx.Instance = DMA1_Channel7;
    hdma_usart2_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_usart2_tx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart2_tx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart2_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart2_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart2_tx.Init.Mode = DMA_NORMAL;
    hdma_usart2_tx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart2_tx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmatx,hdma_usart2_tx);

  /* USER CODE BEGIN USART2_MspInit 1 */

  /* USER CODE END USART2_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspDeInit 0 */

  /* USER CODE END USART1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

    /* USART1 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmarx);
    HAL_DMA_DeInit(uartHandle->hdmatx);
  /* USER CODE BEGIN USART1_MspDeInit 1 */

  /* USER CODE END USART1_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspDeInit 0 */

  /* USER CODE END USART2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART2_CLK_DISABLE();

    /**USART2 GPIO Configuration
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_2|GPIO_PIN_3);

    /* USART2 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmarx);
    HAL_DMA_DeInit(uartHandle->hdmatx);
  /* USER CODE BEGIN USART2_MspDeInit 1 */

  /* USER CODE END USART2_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
static uint8_t dma_tx_flag = 0;//uart�����ѿ�ʼ��־
/**
  * @brief uart�������ݰ����
  * @retval
  * 0x01 :֡ͷ����
  * 0x02 :���ݰ����ȴ���
  * 0x03 :֡β����
  * 0x04 :У��ʹ���
  * 0xAA :���ݰ���ȷ
  */
uint8_t RXpack_check()
{
  uint16_t check_sum=0;
  uint8_t i=0;
  uart_RXpack_length = uart_rx_buf[2]+5;//data����+
  if (uart_rx_buf[0]!=first_byte)
  {
    return 0x01;//
  }
  else if ((uart_rx_buf_length-__HAL_DMA_GET_COUNTER(&hdma_usart1_rx))!=uart_RXpack_length)  
  {
    return 0x02;//
  }
  else if (uart_rx_buf[uart_RXpack_length-1]!=last_byte)
  {
    return 0x03;//
  }
  else 
  {
    for ( i = 0; i < uart_RXpack_length-2; i++) //��byte0 ��ʼ
    {
      check_sum += uart_rx_buf[i];
    }
    if ((uint8_t)(check_sum & 0xFF) != uart_rx_buf[uart_RXpack_length-2])//ȡSUM��8λ �뵹����2���ֽڱȽ�
    return 0x04;//
  }
  return 0xAA;//
}
/**
  * @brief �����������ݰ�
  * @param len �û����ݳ���
  * @retval
  */
void TXpack(uint8_t cmd,uint8_t len)
{
  uint8_t i;
  uint16_t sum = 0;
	#define pack_len len+5
	
  uart_tx_buf[0] = first_byte;
  uart_tx_buf[1] = cmd;
  uart_tx_buf[2] = len;
  uart_tx_buf[pack_len-1] = last_byte;
  for ( i = 0; i < pack_len-2; i++)
  {
    sum += uart_tx_buf[i];
  }
  uart_tx_buf[pack_len-2] = (uint8_t)(sum & 0xFF);
}
/**
  * @brief ����cmd
  * @param cmd_type //EE��AA��EE:errorָ�AA:�������
  * @param cmd_code //cmd����
  * @retval
  */
/*
void uart_send_cmd(uint8_t cmd_type,uint8_t cmd_code)
{
  uart_tx_buf[2] = cmd_type;
  uart_tx_buf[3] = cmd_code; //���ش������
  TXpack(6);
  HAL_UART_DMAStop(&huart1);
  HAL_DMA_Init(&hdma_usart1_tx);
  huart2.gState = HAL_UART_STATE_READY;	
  HAL_UART_Transmit_DMA(&huart1,uart_tx_buf,6);
  dma_tx_flag = 1;
}*/
/**
  * @brief �������ݰ���������Ϊtx mode
  * @param length �û����ݳ���
  * @retval 
  */
void uart_send_pack(uint8_t cmd,uint8_t length)
{
  TXpack(cmd,length);
  HAL_UART_DMAStop(&huart1);
  HAL_DMA_Init(&hdma_usart1_tx);
//  huart1.gState = HAL_UART_STATE_READY;	
  HAL_UART_Transmit_DMA(&huart1,uart_tx_buf,length+5);
  dma_tx_flag = 1;
}
/**
  * @brief ����uart_dma����ģʽ
  * @retval
  */
void uart_dma_rx_mode()
{
	HAL_DMA_Abort(&hdma_usart1_rx);
  HAL_DMA_Init(&hdma_usart1_rx);
  HAL_UART_Receive_DMA(&huart1,uart_rx_buf,uart_rx_buf_length);//����ģʽ
}
/**
  * @brief  uart����������1ms����1��
  * @retval 
  */
uint8_t RXpack_sta;
bool RC_success_flag = 0;
void uart_service()
{
  static uint8_t uart_timeout_cnt = 0;
  static uint16_t RC_timeout_cnt = 0;
  static uint16_t RC_success_cnt = 0;	
  RC_timeout_cnt++;
  uint8_t i;
  if (RC_timeout_cnt > 500)//����500msû�յ����ݰ�
  {
    RC_timeout_cnt = 0;
		HAL_UART_Init(&huart1);
		uart_dma_rx_mode();
    RC_timeout_set;
		RC_success_flag = 0;
		RC_success_cnt=0;
  }
  if(RC_success_cnt>5)
	{
		RC_success_cnt=0;
		RC_success_flag = 1;
	}		
  if (dma_tx_flag == 1)//uart��������
  {
    if (HAL_DMA_GetState(&hdma_usart1_tx) == HAL_DMA_STATE_READY)//dma�������
    {
      dma_tx_flag = 0;
      uart_dma_rx_mode();
    }  
  }
  else
  {
    if (__HAL_DMA_GET_COUNTER(&hdma_usart1_rx)!=uart_rx_buf_length)//dma���俪ʼ
    {
      uart_timeout_cnt++;
      if (uart_timeout_cnt>4)//4~5ms�����������ݰ�
      {
        HAL_UART_DMAStop(&huart1);//ֹͣ���գ���ֹ������ݰ�ʱ�յ�����
        uart_timeout_cnt = 0;
        RXpack_sta = RXpack_check();
        if (RXpack_sta != 0xAA)//���ݰ�����
        {
          uart_dma_rx_mode();
        }
        else //���ݰ�����
        {
          RC_timeout_cnt=0;
					RC_success_cnt++;
					RC_timeout_reset;
					switch (uart_rx_buf[1])//CMD_ID
          {
          case 0xAA://ʹ�ܷɿ�
            user_enable_flight;
						uart_dma_rx_mode();
            //uart_send_cmd(0xAA,0x00);
            break;
          case 0xFF://ʧ�ܷɿ�
            user_disable_flight;
						uart_dma_rx_mode();
            //uart_send_cmd(0xAA,0x01);
            break;
					case 0x01: //ҡ�˿���
						BYTE0(RC_Control.YAW) = uart_rx_buf[3];
						BYTE1(RC_Control.YAW) = uart_rx_buf[4];
						BYTE0(RC_Control.THROTTLE) = uart_rx_buf[5];
						BYTE1(RC_Control.THROTTLE) = uart_rx_buf[6];
						BYTE0(RC_Control.ROLL) = uart_rx_buf[7];
						BYTE1(RC_Control.ROLL) = uart_rx_buf[8]; 
						BYTE0(RC_Control.PITCH) = uart_rx_buf[9];
						BYTE1(RC_Control.PITCH) = uart_rx_buf[10];     
            uart_dma_rx_mode();              
						break;
					case 0x02://������̬У׼
						BYTE0(yaw_offset) = uart_rx_buf[3];
						BYTE1(yaw_offset) = uart_rx_buf[4];						
						BYTE0(roll_offset) = uart_rx_buf[5];
						BYTE1(roll_offset) = uart_rx_buf[6];
						BYTE0(pit_offset) = uart_rx_buf[7];
						BYTE1(pit_offset) = uart_rx_buf[8];
            flash_data[31] = 	yaw_offset;
            flash_data[32] = 	roll_offset;
            flash_data[33] = 	pit_offset;
           			
						offset_save_flag = 1;
						uart_dma_rx_mode();
						break;
					case 0x03://������У׼
						att_offset_flag = 1;
						uart_dma_rx_mode();
					break;					
          case 0x04://��ȡ��ص�ѹ
            uart_tx_buf[3] = BYTE0(battery_vot);
            uart_tx_buf[4] = BYTE1(battery_vot);
            uart_tx_buf[5] = BYTE2(battery_vot);
            uart_tx_buf[6] = BYTE3(battery_vot);
					  uart_dma_rx_mode();              						
           /* uart_send_pack(0x04,4);*/
            break;

          case 0x05://����yaw���ٶȻ� pid����
            for ( i = 0; i < 5; i++)
            {
              flash_data[i+1] = (int16_t)(uart_rx_buf[(i<<1)+4] << 8) | (uart_rx_buf[(i<<1)+3]);
            }
            pidRateZ.kp = (float)flash_data[1]/100;    
            pidRateZ.ki = (float)flash_data[2]/100;    
            pidRateZ.kd = (float)flash_data[3]/100;    
            pidRateZ.ilimt = (float)flash_data[4]/100;    
            pidRateZ.irange = (float)flash_data[5]/100;
						uart_dma_rx_mode();              						

          pid_save_flag = 1;
					break;
          case 0x06://����yaw�ǶȻ� pid����
            for ( i = 0; i < 5; i++)
            {
              flash_data[i+6] = (int16_t)(uart_rx_buf[(i<<1)+4] << 8) | (uart_rx_buf[(i<<1)+3]);
            }
            pidYaw.kp = (float)flash_data[6]/100;    
            pidYaw.ki = (float)flash_data[7]/100;    
            pidYaw.kd = (float)flash_data[8]/100;    
            pidYaw.ilimt = (float)flash_data[9]/100;    
            pidYaw.irange = (float)flash_data[10]/100; 
						uart_dma_rx_mode();              						
            pid_save_flag = 1;
					break;
          case 0x07://����pitch���ٶȻ� pid����
            for ( i = 0; i < 5; i++)
            {
              flash_data[i+11] = (int16_t)(uart_rx_buf[(i<<1)+4] << 8) | (uart_rx_buf[(i<<1)+3]);
            }
            pidRateX.kp = (float)flash_data[11]/100;    
            pidRateX.ki = (float)flash_data[12]/100;    
            pidRateX.kd = (float)flash_data[13]/100;    
            pidRateX.ilimt = (float)flash_data[14]/100;    
            pidRateX.irange = (float)flash_data[15]/100;   
						uart_dma_rx_mode();              						
            pid_save_flag = 1;
					break;
          case 0x08://����pitch�ǶȻ� pid����
            for ( i = 0; i < 5; i++)
            {
              flash_data[i+16] = (int16_t)(uart_rx_buf[(i<<1)+4] << 8) | (uart_rx_buf[(i<<1)+3]);
            }
            pidPitch.kp = (float)flash_data[16]/100;    
            pidPitch.ki = (float)flash_data[17]/100;    
            pidPitch.kd = (float)flash_data[18]/100;    
            pidPitch.ilimt = (float)flash_data[19]/100;    
            pidPitch.irange = (float)flash_data[20]/100;
						uart_dma_rx_mode();              						
            pid_save_flag = 1;
					break; 
          case 0x09://����roll�ǶȻ� pid����
            for ( i = 0; i < 5; i++)
            {
              flash_data[i+21] = (int16_t)(uart_rx_buf[(i<<1)+4] << 8) | (uart_rx_buf[(i<<1)+3]);
            }
            pidRateY.kp = (float)flash_data[21]/100;    
            pidRateY.ki = (float)flash_data[22]/100;    
            pidRateY.kd = (float)flash_data[23]/100;    
            pidRateY.ilimt = (float)flash_data[24]/100;    
            pidRateY.irange = (float)flash_data[25]/100;  
						uart_dma_rx_mode();              						
            pid_save_flag = 1;
					break; 
          case 0x0a://����roll�ǶȻ� pid����
            for ( i = 0; i < 5; i++)
            {
              flash_data[i+26] = (int16_t)(uart_rx_buf[(i<<1)+4] << 8) | (uart_rx_buf[(i<<1)+3]);
            }
            pidRoll.kp = (float)flash_data[26]/100;    
            pidRoll.ki = (float)flash_data[27]/100;    
            pidRoll.kd = (float)flash_data[28]/100;    
            pidRoll.ilimt = (float)flash_data[29]/100;    
            pidRoll.irange = (float)flash_data[30]/100; 
						uart_dma_rx_mode();             						
            pid_save_flag = 1;
					break;  
          case 0x0b://��ȡyaw�ǶȻ� pid����
            for ( i = 0; i < 5; i++)
            {              flash_data[i+26] = (int16_t)(uart_rx_buf[(i<<1)+4] << 8) | (uart_rx_buf[(i<<1)+3]);
            }
            pidRoll.kp = (float)flash_data[26]/100;    
            pidRoll.ki = (float)flash_data[27]/100;    
            pidRoll.kd = (float)flash_data[28]/100;    
            pidRoll.ilimt = (float)flash_data[29]/100;    
            pidRoll.irange = (float)flash_data[30]/100; 
						uart_dma_rx_mode();             						
            pid_save_flag = 1;
					break;                                                           

          default:
						uart_dma_rx_mode();
            break;
          }
        }
        
      }   
    }
  }  
}


/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
