#ifndef		__LED_H
#define		__LED_H

#include "main.h"

#define LED_Blue_ON    	  HAL_GPIO_WritePin(LED_Blue_GPIO_Port,LED_Blue_Pin,GPIO_PIN_SET)
#define LED_Blue_OFF   	  HAL_GPIO_WritePin(LED_Blue_GPIO_Port,LED_Blue_Pin,GPIO_PIN_RESET)
#define LED_Red_ON    	  HAL_GPIO_WritePin(LED_Red_GPIO_Port,LED_Red_Pin,GPIO_PIN_SET)
#define LED_Red_OFF   	  HAL_GPIO_WritePin(LED_Red_GPIO_Port,LED_Red_Pin,GPIO_PIN_RESET)
#define LED_Blue_Reverse  HAL_GPIO_TogglePin(LED_Blue_GPIO_Port,LED_Blue_Pin)
#define LED_Red_Reverse  	HAL_GPIO_TogglePin(LED_Red_GPIO_Port,LED_Red_Pin)

void pilot_LED(void);


#endif
